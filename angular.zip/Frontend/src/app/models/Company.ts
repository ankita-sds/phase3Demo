export interface Company {
  id?: number;
  name?: string;
  turnover?: string;
  ceo?: string;
  boardOfDirectors?: string;
  sectorname?: string;
  companyBrief?: string;
}

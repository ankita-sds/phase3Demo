export interface Companystockmap {
  id?: number;
  companycode?: string;
  stockexchangename?: string;
  companyname?: string;
}

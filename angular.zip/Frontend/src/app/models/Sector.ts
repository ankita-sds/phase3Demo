export interface Sector {
  id?: number;
  name?: string;
  description?: string;
}
